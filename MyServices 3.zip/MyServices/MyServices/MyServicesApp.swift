//
//  MyServicesApp.swift
//  MyServices
//
//  Created by Turma02-2 on 27/02/25.
//

import SwiftUI

@main
struct MyServicesApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
